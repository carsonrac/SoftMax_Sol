package com.simplilearn.softmaxpos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftmaxPosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoftmaxPosApplication.class, args);
	}

}
